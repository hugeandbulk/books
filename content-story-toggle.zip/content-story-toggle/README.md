# Content story toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/Katastronaut/pen/GRXOyZZ](https://codepen.io/Katastronaut/pen/GRXOyZZ).

