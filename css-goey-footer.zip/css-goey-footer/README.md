# CSS Goey footer

A Pen created on CodePen.io. Original URL: [https://codepen.io/z-/pen/zYxdRQy](https://codepen.io/z-/pen/zYxdRQy).

I'm a little late to the blob party, but I'm having fun  
Do not use this for real projects with this amount of blobs, use 24 of them or less 😛  
_  
  
Made using GistPad https://aka.ms/gistpad  
Pen available as a Gist: https://gist.github.com/oauo/ecdf56c499e809ad671c4d85d5c2b90a  
Open in GistPad: <vscode://vsls-contrib.gistfs/open?gist=ecdf56c499e809ad671c4d85d5c2b90a>