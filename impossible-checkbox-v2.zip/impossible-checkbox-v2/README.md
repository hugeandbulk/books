# Impossible Checkbox v2 🐻

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/LYNZwGm](https://codepen.io/jh3y/pen/LYNZwGm).

Revisiting one of my favorite pens to update the React side of it and add sound 