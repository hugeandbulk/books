const toggleMenu = () => {
  const openMenu = document.querySelector(".btn-open");
  const closeMenu = document.querySelector(".btn-close");
  openMenu.addEventListener("click", () => {
    openMenu.classList.toggle("btn-back");
    closeMenu.classList.toggle("btn-front");
  });
  closeMenu.addEventListener("click", () => {
    closeMenu.classList.toggle("btn-front");
    openMenu.classList.toggle("btn-back");
  });
};

toggleMenu();
