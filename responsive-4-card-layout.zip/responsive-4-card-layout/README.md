# Responsive 4 card layout

A Pen created on CodePen.io. Original URL: [https://codepen.io/whoiswardlarson/pen/dyqVLKp](https://codepen.io/whoiswardlarson/pen/dyqVLKp).

I'm sick of putting everything into columns which I feel like breaks flow on a lot of projects. I decided to make a nice alternating card layout with text that lines up on the left for easier reading.