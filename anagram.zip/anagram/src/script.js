const initialWord = 'Anagrams ';
// An array containing the new positions of the letters
const newPositions = [0,4,7,8,6,2,3,1,5];

gsap.registerPlugin(Flip);

let isInitial = true;

const anagramContainer = document.querySelector("#anagram");

const getElementArrayFromWord = word => {
  let letterArray = initialWord.split('');
  let elementArray = [];
  for (let i = 0; i < letterArray.length; i++) {
    const sp = document.createElement("span");
    const node = document.createTextNode(letterArray[i]);
    sp.appendChild(node);
    elementArray.push(sp);
  }
  return elementArray;
}

const elementArray = getElementArrayFromWord(initialWord);
for (let i = 0; i < elementArray.length; i++) {
  anagramContainer.appendChild(elementArray[i]);
}

const rearrange = () => {
  let state = Flip.getState(elementArray);

  for (let i = 0; i < elementArray.length; i++) {
    if (isInitial) {
      anagramContainer.appendChild(elementArray[newPositions[i]]);
    } else {
      anagramContainer.appendChild(elementArray[i]);
    }
  }
  isInitial = !isInitial;
  Flip.from(state, {
    duration: 2,
    ease: "back.inOut",
    stagger: 0.1,
  });
}

anagramContainer.addEventListener("click", rearrange);
  