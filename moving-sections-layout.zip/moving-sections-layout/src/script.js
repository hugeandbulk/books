/* Variables */

const carouselGrid = document.querySelector('.carousel-grid');

let carouselGridItems = document.querySelectorAll('.carousel-grid__item');
carouselGridItems = Array.from(carouselGridItems);

let menuItems = document.querySelectorAll('.menu__item');
menuItems = Array.from(menuItems);

/* Event listener */

menuItems.forEach((menuItem) => {
    menuItem.addEventListener('click', () => {
        
        let itemDataNumber = menuItem.attributes["data-number"].nodeValue.toString();

        switch(itemDataNumber) {
            case 'one':
                carouselGrid.style = "left: 15vw";   
                doSmoothTransition(itemDataNumber);            
                break;
            case 'two':
                carouselGrid.style = "left: -55vw";
                doSmoothTransition(itemDataNumber);            
                break;
            case 'three':
                carouselGrid.style = "left: -125vw";
                doSmoothTransition(itemDataNumber);            
                break;
        }

    });
});

/* Function */

function doSmoothTransition(itemDataNumber) {
    carouselGridItems.forEach(carouselGridItem => {
        if(carouselGridItem.attributes["data-number"].nodeValue.toString() == itemDataNumber) {
            carouselGridItem.classList.add('visible');
        } else {
            carouselGridItem.classList.remove('visible');
        }
    });
}