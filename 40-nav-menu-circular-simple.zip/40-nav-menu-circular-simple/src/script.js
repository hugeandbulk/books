const { ref, methods } = Vue;
const App = {
  setup(){ 
    const toggle = ref(null)
    const menu = ref(null)
    const msg = ref('');
    const icons = ref([{
      image: 'fa-brands:github-alt'
    },
    {
      image: 'fa-brands:linkedin-in'
    },
    {
      image: 'fa-brands:instagram'
    },
    {
      image: 'fa-brands:twitter'
    }, 
    {
      image: 'fa-brands:reddit-alien'
    },
    {
      image: 'fa-brands:twitch'
    },
    {
      image: 'fa-brands:whatsapp'
    },                      
])
    
    const active = () => {
       menu.value.classList.toggle('active')
    }
    return{
      icons,
      msg,
      toggle,
      menu,
      active,
    };
  },
};
Vue.createApp(App).mount('#app');