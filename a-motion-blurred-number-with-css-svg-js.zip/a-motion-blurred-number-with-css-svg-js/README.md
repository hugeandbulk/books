# A Motion Blurred Number with CSS / SVG / JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/konstantindenerz/pen/zYJzvEQ](https://codepen.io/konstantindenerz/pen/zYJzvEQ).

