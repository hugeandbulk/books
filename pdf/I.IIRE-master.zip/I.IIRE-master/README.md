# I.IIRE<sup>®</sup>: Intelligent Interactive Research Environment.

## [![NPM](https://img.shields.io/badge/npm-status-green.svg)](https://www.npmjs.com/~quantumomics)

## About
<b>∞</b>, (Infinite) is a concept of switching the next generation intelligent interactive way to do the science experiment with moral and ethical values earned by any experimentalist and an eminent scientist.

<b>∞</b>, (Infinite) is a next generation intelligent interactive research environment for the new generation of science to deal with any research activity at some capacity for the smart experimentalist or scientist. The meaning of <b>∞</b>, (Infinite) is any science experiment and research can be possible with the support of infinite way of reactions possibilities with the limitless arrangement or rearrangement of study or research related to the any scientific disciplines (mainly it's designed for molecular biology, bacteriology, virology, genomics, proteomics, transcriptomics, metabolomics, and reactomics).

So, according to the explained philosophy, Infinite is build for 1) intelligent molecule storage environment, 2) intelligent interactive reaction environment, 3) intelligent spots reaction environment, and 4) intelligent array reaction environment. All of geared with the state-of-the-art design and specifications with laboratory protocol(s) to deal with not limited to store and doing the reactions with respect to time, also smart scientist now have capability at some capacity to handle more to out some brilliant research to solve the discovery, invention, and innovations; because of infinite the giant leap is created.

<b>(∞)Infinite</b>, acquired the trade name and it's given principle, and philosophy; finally coined by Prabhat Kumar - I.IIRE®: Intelligent Interactive Research Environment.

### Nomenclature (∞) Infinite(s)
Nomenclature of Infinite is a set or system of names that is invented and terms given after for easy and convenient way to do the research with identification of particular purpose.

The infinite is classified in to <b>four research system</b> and with some smart principle(s) and protocol(s):-

<b>∞</b>.IIRE, nomenclatured below, please go from here:

<b>(1)</b> Intelligent Molecule Storage Environment

Mother Nature invented many molecules, like nucleic acids (DNA/RNA), proteins, enzymes and carbohydrates. Due to these molecules life becomes possible and we’re storing it for future research.

Color: RGB(4,9,9) | Hex (#040909) | HSV(180°,56%,4%) = Cap Color.

i) <b>∞<sup>Ψ</sup></b> - Nascent Intelligent Molecule Storage Environment

ii) <b>∞<sup>Ψ.1</sup></b> - α Intelligent Molecule Storage Environment

iii) <b>∞<sup>Ψ.2</sup></b> - β Intelligent Molecule Storage Environment

iv) <b>∞<sup>Ψ.4</sup></b> - δ Intelligent Molecule Storage Environment

v) <b>∞<sup>Ψ.9</sup></b> - ι Intelligent Molecule Storage Environment

<b>(2)</b> Intelligent Interactive Reaction Environment

Color: RGB(9,4,9) | Hex (#090409) | HSV(300°,56%,4%) = Ring Color.

i) <b>∞<sup>Ω</sup></b> - Nascent infinite reaction environment

ii) <b>∞<sup>Ω.Ti.22</sup></b> - Titanium Infinite Reaction Environment

iii) <b>∞<sup>Ω.Cu.29</sup></b> - Copper Infinite Reaction Environment

iv) <b>∞<sup>Ω.Ag.47</sup></b> - Silver Infinite Reaction Environment

v) <b>∞<sup>Ω.Au.79</sup></b> - Gold Infinite Reaction Environment

(3) Intelligent Spots Reaction Environment

Color: RGB(9,9,4) | Hex (#090904) | HSV(60°,56%,4%) = Rectangular Color.

i) <b>∞<sup>λ</sup></b> - Nascent infinite spots reaction environment

   if we have types of spotsarrays included, it would be below defined:
   
      DNA spotsarray,
      
      RNA spotsarray,
      
      Protein spotsarray,
      
      Tissue spotsarray,
      
      Cellular spotsarrays (also called transfection spotsarray),
      
      Chemical compound spotsarrays,
      
      Antibody spotsarrays,
      
      Carbohydrate spotsarrays,
      
      Phenotype spotsarrays.

(4) Intelligent Array Reaction Environment

Color: RGB(4,4,9) | Hex (#040409) | HSV(240°,56%,4%) = Rectangular Color.

i) <b>∞<sup>φ</sup></b> - Nascent infinite array reaction environment

      if we have types of microarrays included, it would be below defined:
      
- <b>∞<sup>φ.δ</sup></b> - gene expression microarrays, and
      
- <b>∞<sup>φ.ω</sup></b> - genome expression microarrays.

(5) Intelligent Weight Array Reaction Environment
<b>∞<sup>δ</sup></b>

These above are the <b>∞</b> naming principle of our Intelligent Interactive Research Environment to deal with future sciences.

Thanks,

Prabhat Kumar, CEO & Founder, <b>Quantumomics, Inc</b>.

Ӝ — Prabhat Kumar,</br>
<b>№ 4°9</b>, Ignited Engine,</br>Neurone Avenue,</br>
<b>√•</b> Circuit Nearly,</br>※ Earth.
