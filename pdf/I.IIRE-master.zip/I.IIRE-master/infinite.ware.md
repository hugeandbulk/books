## InfiniteWare

(1)	Intelligent Molecule Storage Environment
  - Volume
  - Material
              
              -	Glass
              - Ceramic
              - HDPE/LDPE
              - Electronics [Au]
              - Electrode [Cu]
	- Dimension (length * width * height)
	- Weight
  - Amount of Storing the Molecules
	- Storage Temperature (+/- °C)	
