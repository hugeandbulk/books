## Study Plan
{A} We have to study about the relationship of Tm °C and humidity for Glass, Ceramic, HDPE/LDPE, Gold Electronics, and Copper Electrodes, with respect to time (Δt).

{B} Electrical and Mechanical Noise for the nucleic acid (DNA/RNA), protein, and enzymes:
	a. respective to the molecules, and
	b. noise constant derivation.

{C} Humidity related study for the nucleic acid (DNA/RNA), protein, and enzymes:
	All form of DNA,
	rRNA
	tRNA
	snRNA
	hnRNA

{D} Extinction coefficient related study for the nucleic acid (DNA/RNA), protein, and enzymes.

{E} SAR (Specific Absorption Rate) related study for the nucleic acid (DNA/RNA), protein, and enzymes.
