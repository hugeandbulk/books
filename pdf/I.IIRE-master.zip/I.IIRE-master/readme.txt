## I.IIRE®: Intelligent Interactive Reaction(s) Environment.

I.IIRE - is become possible when we have at least two Noid(s).
├── [1]. Reaction(s) + Noid(s) => ReactionNoid => React[ion<sup>+/-</sup>]Noid
│   ├── idea
│   ├── idea
│   ├── idea
│   └── idea
└── [1]. Soul(s) + Noid(s) => SoulNoid
    ├── idea
    └── idea
