# ¶ [EOS]
<b>[EOS]</b>, is a term coined by Prabhat Kumar, to use it in the field of bioinformatics with the respect to the molecules (namely — nucleic acids, peptides, proteins, carbohydrates and enzymes), indicating that the end of it's usefulness, and finally a stop for reading it.
It is the ignited simply, intended to limit or end support for the <b>KSN.1</b>.

<b>Syntax:</b> [ID:№{№:№}]

<b>Notations:</b> [ ] – envelope, ‹› – ket(s), : or :: – separator, { } – enclosure, and № — number.

<b>Semantics:</b>

<b>Example:</b> [5AF4‹1›{1:1}]
