# Engineering

Kumar Notations: Kumar notations is enclosed with [], enveloped with {} or |, separated with :, notified with •, and numbers are allowed from 0 to 9, only.
