# KSN.1<sup>®</sup> = Kumar Syntax Nomenclature.1
<b>KSN.1<sup>®</sup></b>, is a international syntax nomenclature invented and designed for research and general use for the scientists and people.
It's have principles and rules for next generation of doing sciences. Any discovery can be organised hopefully at some capacity with the same. It's classified for several distinct disciplines for easy use of nomenclature by identifying the problem statements.

We're organising the KSN.1 for the below disciplines:-

1. Astronomy
2. Bioinformatics
3. Biochemistry
4. Chemistry
5. Physics
6. Engineering
