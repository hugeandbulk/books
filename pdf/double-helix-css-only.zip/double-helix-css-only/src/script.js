// See https://codepen.io/creativeocean/pen/abLRNVL?editors=1010 for the original
