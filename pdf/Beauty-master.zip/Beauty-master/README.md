# Beauty
> Noun

<i>Beauty is a combination of qualities, such as shape, colour, or form, that pleases the aesthetic senses, especially the sight</i>.

<b>Kumar(Ψ)</b> Theorem, Corollary, Lemma and Proof.

¶ Theorem:

1. In nature, there is only one possibility and that is <b>Beauty</b>.

2. Each and every creations of mother nature have Beauty.

3. Beauty is associated with the creations.

4. Each and every creations have an art and driving force behind that is thought.

5. Each and every thought need philosophy, and it retains the possibility of mathematical equations.

6. In nature, each and every creations have equations.

7. Beauty driven by a mathematical equations.

8. Beauty is unit less.

9. Beauty is a philosophy.

¶ Proof(s):

1. Beauty is a jewellery itself.

2. Beauty is an imposed feature of any object and when it is exposed becomes a jewellery.

3. Beauty is an emotional guidance driven by mental health.

4. Beauty is a factory of genuine and honest expressions.

5. Beauty exposed to expression, becomes beautiful.

6. Beauty is like a magnet, which can attract expressions of yourself.

7. Beauty is an expressions of magnetism for beauty of others.

8. Beauty is a personality related expression to govern intelligence and gravity.

9. Beauty is an inverse of ugly, a truth originates from every expressions.

10. Beauty is a physical variable that depends upon execution of the same, with the respect to time.

11. Beauty is limited to an experiment.

12. Beauty is correlation with you and me, please carry on.

13. Beauty is a natural phenomenon, related to consequences of the healthy diet.

14. Beauty is a great weekness of a beautiful women.

15. Beauty is a great exposure of a mind, and experienced through upgradation.

16. Beauty is a connection of crime, but not a crime. - FBI.

17. Beauty is a...., after that we will see. MI6.

18. Beauty is a mistake of our mind. AUS Police.

19. Beauty is misleaded by any one, may be you. IG.

20. Beauty is a genome drama. — Sanger Institute.

21. Beauty is a gene, who regulates the family of genes. — Prabhat Kumar.

22. Beauty is a stereochemistry, related to undefective nature of elements. — Prabhat Kumar.

¶ 😘 Proof(s):

1. If I am beautifool, i have to concern myself to not lose the earnings of the respect.

2. If I am beautifool, i have to worry about smart and caring people.

3. If I am beautifool, i can understand myself, what's next.

4. If I am beautifool, i can go for performance of myself related to moral and ethics.

4. If I am beautifool, i would like to be more specific.
