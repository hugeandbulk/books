# Preface
Preface is just a tool limited to my own experimental edition of genes but with some junk DNA that is, I sure never have been verified in Sanger Institute; definitely Yet.

So, as per the journey with empty stomach, only philosophy and writing on the GitHub (https://github.com/) — The Literature, it is a huge amount of mental tissue work and I have been taken it seriously when it was comes across the people as a subject, and becomes debatable. What do you think, I am really interested, Yeah. I am committed on the 5<sup>th</sup> September; please hopefully be careful, It is a start.

So, first it was that; second it was a tea — but directed to the unknown recipe. After that OUP (http://global.oup.com/) said verbally without the phone and landline. Because, they are thinking the email is really good, but not received yet.

I am really applied because of the stupid promise — that ideas comes true to understand Beauty. Because, I was never been a philosopher; so, do not hate me. I am not going to say, "Please".

<b>Prabhat Kumar</b>,</br>Patna, India.
