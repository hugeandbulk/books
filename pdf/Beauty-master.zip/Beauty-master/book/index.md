¶ <b>Theorem(s)</b>:


α.Philosophy
------------

1. In nature, there is only one possibility and that is <b>Beauty</b>.

2. Each and every creations of mother nature have Beauty.

3. Beauty is associated with the creations.

4. Each and every creations have an art and driving force behind that is thought.

5. Each and every thought need philosophy, and it retains the possibility of mathematical equations.

6. In nature, each and every creations have equations.

7. Beauty driven by a mathematical equations.

8. Beauty is unit less.

9. Beauty is a philosophy.
