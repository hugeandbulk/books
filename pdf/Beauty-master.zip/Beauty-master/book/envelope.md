# Envelope

## To,
<b>Discovering Beauty</b>, with <i>philosophy and mathematics</i>; is a nicely created by <b>n</b> number of ignited young philosophers and mathematicians; unknown to the subject. So, please let it go year by year endless journey of the beauty.

## From:—
A Lathe Machine,</br>
<b>№ 4°9</b>, Ignited Engine,</br>Neurone Avenue,</br>
<b>√•</b> Circuit Nearly,</br>※ Earth.
