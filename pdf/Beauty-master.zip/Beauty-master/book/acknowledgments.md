# Acknowledgements
<p style="text-align:justify"><b>Beauty</b> is an origin of the human mind; driven by thoughtful decisions ignited by philosophy and proved by mathematical approaches.
On mother earth, I got many thoughtful minds who has been given support to me to pen down these ignited sentences to finally bounded in to the form of a book. So, I would like to pay thanks, due to greatness of those people this journey becomes true.</p>To contribute, some people given many happy memories and their hours to be able to finally give a gift to you by a publisher.

These are the intellects; Ashley Graham, Priyanka Kumar, Jonna Petterson, Site, and my beloved Kids.

These are some artists who brushed on a metal and given joy for the cover.

<i>Note</i>: References taken are Licensed from Creative Commons is Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0) | https://creativecommons.org/licenses/by-sa/3.0/

<b>Prabhat Kumar</b>, </br> 05<sup>th</sup> September.
