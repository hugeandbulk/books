# Contents


<i>“Life isn't worth living, unless it is lived for someone else.”</i> ― <b>Albert Einstein</b>.

  <b>Introduction</b>
  
  <b>Face</b>
  
     <b>α.</b>Philosophy</br>       ― 9 Theorem(s)
     <b>β.</b>Nature</br>           ― 9 Theorem(s)
     <b>γ.</b>Creator</br>          ― 9 Theorem(s)
     <b>δ.</b>Originator</br>       ― 9 Theorem(s)
     <b>ε.</b>Navigator</br>        ― 9 Theorem(s)
     <b>ζ.</b>Transporter</br>      ― 9 Theorem(s)
     <b>η.</b>Culminator</br>       ― 9 Theorem(s)
     <b>θ.</b>Professor</br>        ― 9 Theorem(s)
     <b>ι.</b>Mathematics           ― 9 Theorem(s)
     ---------------------------------------------
     Total                          = 81 Theorem(s)
  Illustrations
  
  Glossary
  
  Appendices
  
  References
  
  Index
  
  ∆ Ugly Artwork
  
  ∆ Cover Artwork
