## Calculations
¶ Reading Time = How much proposed penalty to you <b>/</b> You're interest to confused

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Where, I am the Mathematician.
