# Sufface
Sufface is now a verified behaviours of my own experimental editions of genes but with some junk DNA that was, removed by Sanger Institute and I am confused sure about that — for instance, "I am designed for the confusion or applied for the nature".

Yet, it is an established proof, with <b>81<sub><sup>(9 × 9)</sup></sub></b> = Beauty Theorems.

<i>fool</i>mail: [discovering.beauty](discovering.beauty@outlook.com)@outlook.com</br>
<i>fool</i>poll: https://twitter.com/BeautyScale


<b>Prabhat Kumar</b>,</br>
<b><sup>4•9</sup>§<sub><sup>19°79</sup></sub></b>,</br>
<b>№ 4°9</b>, Ignited Engine,</br>Neurone Avenue,</br>
<b>√•</b> Circuit Nearly,</br>※ Earth.
