# Open
### Write a program to discover Beauty.
<i>If</i>, you have received this creation,</br>
<i>Please</i>, let your mind first to be confused,</br>
<i>After</i>, that be isolated & switch off all nonsense,</br>
<i>Finally</i>, be a philosopher at least.</br>

### compilation...
Welcome to the <b>beauty</b>.
### results
A beautiful.
