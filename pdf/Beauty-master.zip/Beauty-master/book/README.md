> Prabhat Kumar
# Discovering Beauty
  <i>philosophy and mathematics</i></br>
  <b>A Very Short Introduction</b>
