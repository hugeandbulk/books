## <b>¶ Beauty Quotient</b>

¶ Beauty Quotient or BQ — is a wide definition to some extent. Every individual has his/her BQ, which constitutes of physical health, psychological health as well as personal appearance.

¶ This quotient is made up of four distinct categories: Physical Health, Psychological Health, Personal Appearance and Personal Soul:

<b>1.</b> Physical Health consists of corporeal characteristics that define a human’s beauty, and trust me — each and every human has physical characteristics that are truly beautiful. A human’s face or body can be structurally imperfect, but still exquisite.

<b>2.</b> Psychological Health involves one’s personality, intelligence, and sensitivity, and warmth, sense of humor, attitude, and overall level of confidence.

<b>3.</b> Personal Appearance includes your beauty routine. This involves habits regarding skin-care regimen, hair and makeup routines, wardrobe, posture, and style.

<b>4.</b> Personal Soul
