# Introduction
A beau•ty is a noun, accordingly in English Grammar. The meaning of the beauty is — a combination of qualities, such as shape, colour, or form, that pleases the aesthetic senses, especially the sight. Beauty is organised in the nature for what?, <i>Agreed</i>.
<b>If yes</b>, there is no not. Then what's that or this! Okay, let be confused. Why to be confused and really it's confusing. So, now agreed, say yes. Okay, boss, okay.

So, pay thanks. The reason for me. Oh oh!, I have written the concept and idea to give you're confusion, that's it. So, now again a question arises about how to pay me. Ah ah!, I have never been given bank account details, so be again confused. So, please let you correct, mail or dial a phone number. But, sorry oh beloved I can't believe on you. Because, till this time you're not confused. So, why you're struggling? Say, and please pay attention.

Okay, so for what I have to pay the attention? Definitely Dear, you know it — "The Beauty". So, I think you know the beauty! But, never been thought a beauty is a subject and subjected to you. Maybe, you are a subject or subjected to the beauty. So, finally you agreed to choose only you're interest, like that! If yes, it's really not going anywhere. But, why? The one again a reason is you're not going to be confused, seriously. If I am communicating with you, you have to at least listen first. Then, you can go for you're mental judgement. Be careful, you are not really sure about the subject, it's fine for you?

Erwin Schrödinger | Schrödinger

<b>Kumar(Ψ)</b>
    .Theorem</br>
    .Corollary</br>
    .Lemma</br>
    .Observation</br>
    .Contradiction</br>
    .Proof

<b>プラバットクマール</b>
