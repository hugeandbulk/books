# References

1. Google, Inc.                   ― https://www.google.com/intl/en/about/
2. Sequømics, Inc.                ― http://sequomics.com/
2. The Wikimedia Foundation, Inc. ― https://wikimediafoundation.org/wiki/Home
3. The Wikipedia                  ― https://en.wikipedia.org/wiki/Wikipedia
