/*
===============================================
Pure CSS - Microsoft Office logos - Word/OneNote/Excel
===============================================
Created by Luca Rensch - ellypite

10/01/2022
===============================================
*/